<p>Hai Admin,</p>

<p>User dengan ID {{ $transaksi->user_id }} belum membayar transaksi dengan ID {{ $transaksi->id }}.</p>
<p>Data Pemeblian : {{ $transaksi->transaksi_data }}</p>

<p>Terima kasih.</p>